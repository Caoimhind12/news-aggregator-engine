import requests
from bs4 import BeautifulSoup
import numpy as np
import pandas as pd
import mysql.connector

wsj_r1 = requests.get('https://www.wsj.com/news/politics')
coverpage_wsj = wsj_r1.content
soup_wsj = BeautifulSoup(coverpage_wsj,'html5lib')
wsj_cover_articles = soup_wsj.find_all('h3',class_='WSJTheme--headline--7VCzo7Ay ')

#scrap only 5 articles
number_of_articles = 15

#empty list
title_wsj = []
author_wsj = []
links_wsj = []
articles_wsj = []
all_publish_date = []

for n in np.arange(0,number_of_articles):
    #getting the links
    link_wsj_politics = wsj_cover_articles[n].find('a')['href']
    links_wsj.append(link_wsj_politics)

    #getting the tiles
    title = wsj_cover_articles[n].find('a').get_text()
    title_wsj.append(title)

    #go to inside the detail view of news
    article = requests.get(link_wsj_politics)
    coverpage_sub_articles = article.content
    soup_sub_article = BeautifulSoup(coverpage_sub_articles, 'html5lib')
    body = soup_sub_article.find_all('section', class_='ArticleBody__Container-sc-1h79tj2-0 fxmbnQ')
    x = body[0].find_all('p')

    # Unifying the paragraphs
    list_paragraphs = []
    for p in np.arange(0, len(x)):
        paragraph = x[p].get_text()
        list_paragraphs.append(paragraph)
        final_article = " ".join(list_paragraphs)

    articles_wsj.append(final_article)


    #publish date
    date_publish_baseline = soup_sub_article.find_all('time', class_='ArticleTimestamp__Timestamp-sc-1ss8ams-0 UeTbO')
    all_publish_date.append(date_publish_baseline[0].get_text())

print(title_wsj)
print(links_wsj)
print(articles_wsj)
print(all_publish_date)